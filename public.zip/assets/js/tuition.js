function loadEditForm(id, year, className, term, amount) {
    document.getElementById('editTuitionId').value = id;
    document.getElementById('editYear').value = year;
    document.getElementById('editClassName').value = className;
    document.getElementById('editTerm').value = term;
    document.getElementById('editAmount').value = amount;
}
