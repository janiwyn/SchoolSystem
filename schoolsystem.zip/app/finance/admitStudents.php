<?php
$title = "Admit Students";
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../middleware/role.php';
require_once __DIR__ . '/../config/cache.php';
$cache = new SimpleCache();

requireRole(['bursar', 'admin', 'principal']);

// Get all classes from fee_structure WITH expected tuition (sum of all terms per class)
$classes = $cache->get('all_classes_with_tuition');

if ($classes === null) {
    // Cache miss - fetch from database
    $classesQuery = "SELECT 
                        fs.class_id, 
                        c.class_name,
                        SUM(fs.amount) AS expected_tuition
                     FROM fee_structure fs 
                     LEFT JOIN classes c ON fs.class_id = c.id 
                     GROUP BY fs.class_id, c.class_name
                     ORDER BY c.class_name ASC";
    $classesResult = $mysqli->query($classesQuery);
    $classes = $classesResult->fetch_all(MYSQLI_ASSOC);
    
    // Cache for 10 minutes (600 seconds)
    $cache->set('all_classes_with_tuition', $classes, 600);
}

// Generate next serial number globally (no Day/Boarding split)
function generateSerialNumber($mysqli) {
    $query = "SELECT MAX(CAST(admission_no AS UNSIGNED)) as max_sn FROM admit_students";
    $result = $mysqli->query($query);
    $row = $result->fetch_assoc();
    $nextSN = ($row['max_sn'] ?? 0) + 1;
    return $nextSN;
}

// Handle form submission
$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admit_student'])) {
    $first_name = trim($_POST['first_name']);
    $gender = trim($_POST['gender']);
    $class_id = trim($_POST['class_id']);
    $day_boarding = trim($_POST['day_boarding']);
    $admission_fee = trim($_POST['admission_fee']);
    $uniform_fee = trim($_POST['uniform_fee']);
    $parent_contact = trim($_POST['parent_contact']);

    // Treat fees as optional: empty = 0
    if ($admission_fee === '' || $admission_fee === null) {
        $admission_fee = 0;
    }
    if ($uniform_fee === '' || $uniform_fee === null) {
        $uniform_fee = 0;
    }

    // Compute expected tuition for this class from fee_structure
    $expected_tuition = 0;
    if ($class_id) {
        $expStmt = $mysqli->prepare("SELECT SUM(amount) AS expected FROM fee_structure WHERE class_id = ?");
        if ($expStmt) {
            $expStmt->bind_param("i", $class_id);
            $expStmt->execute();
            $expRow = $expStmt->get_result()->fetch_assoc();
            $expected_tuition = (float)($expRow['expected'] ?? 0);
            $expStmt->close();
        }
    }

    // Validate required fields (fees NOT required)
    if (!$first_name || !$gender || !$class_id || !$day_boarding || !$parent_contact) {
        $error = "All required fields must be filled";
    } elseif (!is_numeric($admission_fee) || $admission_fee < 0) {
        $error = "Please enter a valid admission fee (0 or more)";
    } elseif (!is_numeric($uniform_fee) || $uniform_fee < 0) {
        $error = "Please enter a valid uniform fee (0 or more)";
    } else {
        // Generate next serial number (global sequence)
        $admission_no = generateSerialNumber($mysqli);

        if (!$error) {
            $user_id = $_SESSION['user_id'] ?? null;
            
            if (!$user_id) {
                $error = "User session error. Please log in again.";
            } else {
                $checkUserStmt = $mysqli->prepare("SELECT id FROM users WHERE id = ?");
                $checkUserStmt->bind_param("i", $user_id);
                $checkUserStmt->execute();
                $userCheckResult = $checkUserStmt->get_result();
                
                if ($userCheckResult->num_rows === 0) {
                    $error = "Invalid user. Please log in again.";
                } else {
                    $status = 'approved';
                    
                    // NOTE: now also inserting expected_tuition
                    $stmt = $mysqli->prepare(
                        "INSERT INTO admit_students 
                            (admission_no, first_name, gender, class_id, day_boarding, 
                             admission_fee, uniform_fee, expected_tuition, parent_contact, 
                             status, created_by, created_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
                    );
                    
                    if ($stmt) {
                        // s,s,s,i,s,d,d,d,s,s,i  => "sssisdddssi"
                        $admission_fee = (float)$admission_fee;
                        $uniform_fee   = (float)$uniform_fee;

                        $stmt->bind_param(
                            "sssisdddssi",
                            $admission_no,
                            $first_name,
                            $gender,
                            $class_id,
                            $day_boarding,
                            $admission_fee,
                            $uniform_fee,
                            $expected_tuition,
                            $parent_contact,
                            $status,
                            $user_id
                        );
                        
                        if ($stmt->execute()) {
                            header("Location: admitStudents.php?student_admitted=1&day_boarding=" . urlencode($day_boarding));
                            exit();
                        } else {
                            $error = "Error admitting student: " . $stmt->error;
                        }
                        $stmt->close();
                    } else {
                        $error = "Database error: " . $mysqli->error;
                    }
                }
                $checkUserStmt->close();
            }
        }
    }
}

// Handle edit form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_student'])) {
    $student_id    = intval($_POST['student_id']);
    $first_name    = trim($_POST['first_name']);
    $gender        = trim($_POST['gender']);
    $class_id      = trim($_POST['class_id']);
    $day_boarding  = trim($_POST['day_boarding']);
    $admission_fee = trim($_POST['admission_fee']);
    $uniform_fee   = trim($_POST['uniform_fee']);
    $parent_contact = trim($_POST['parent_contact']);

    // Make fees optional: empty = 0
    if ($admission_fee === '' || $admission_fee === null) {
        $admission_fee = 0;
    }
    if ($uniform_fee === '' || $uniform_fee === null) {
        $uniform_fee = 0;
    }

    // Recompute expected tuition for (possibly changed) class
    $expected_tuition = 0;
    if ($class_id) {
        $expStmt = $mysqli->prepare("SELECT SUM(amount) AS expected FROM fee_structure WHERE class_id = ?");
        if ($expStmt) {
            $expStmt->bind_param("i", $class_id);
            $expStmt->execute();
            $expRow = $expStmt->get_result()->fetch_assoc();
            $expected_tuition = (float)($expRow['expected'] ?? 0);
            $expStmt->close();
        }
    }

    if (!$first_name || !$gender || !$class_id || !$day_boarding || !$parent_contact) {
        $error = "All required fields must be filled";
    } elseif (!is_numeric($admission_fee) || $admission_fee < 0) {
        $error = "Please enter a valid admission fee (0 or more)";
    } elseif (!is_numeric($uniform_fee) || $uniform_fee < 0) {
        $error = "Please enter a valid uniform fee (0 or more)";
    } else {
        // Get FULL old data before update (for change diff)
        $oldData = null;
        $oldStmt = $mysqli->prepare("SELECT * FROM admit_students WHERE id = ?");
        if ($oldStmt) {
            $oldStmt->bind_param("i", $student_id);
            $oldStmt->execute();
            $res = $oldStmt->get_result();
            $oldData = $res->fetch_assoc();
            $oldStmt->close();
        }

        $mysqli->begin_transaction();
        
        try {
            // 1. Update admit_students table
            $stmt = $mysqli->prepare(
                "UPDATE admit_students 
                 SET first_name = ?, 
                     gender = ?, 
                     class_id = ?, 
                     day_boarding = ?, 
                     admission_fee = ?, 
                     uniform_fee = ?, 
                     expected_tuition = ?, 
                     parent_contact = ?
                 WHERE id = ?"
            );
            
            $admission_fee = (float)$admission_fee;
            $uniform_fee   = (float)$uniform_fee;

            $stmt->bind_param(
                "ssisdddsi",
                $first_name,
                $gender,
                $class_id,
                $day_boarding,
                $admission_fee,
                $uniform_fee,
                $expected_tuition,
                $parent_contact,
                $student_id
            );
            $stmt->execute();
            $stmt->close();

            // 2. Get class name for the new class_id
            $classNameStmt = $mysqli->prepare("SELECT class_name FROM classes WHERE id = ?");
            $classNameStmt->bind_param("i", $class_id);
            $classNameStmt->execute();
            $classNameResult = $classNameStmt->get_result();
            $class_name = $classNameResult->fetch_assoc()['class_name'] ?? '';
            $classNameStmt->close();

            // 3. CRITICAL FIX: Update ALL student_payments records for this student
            // This updates BOTH new and old payment records
            $updatePaymentsStmt = $mysqli->prepare(
                "UPDATE student_payments 
                 SET full_name = ?,
                     gender = ?,
                     class_id = ?,
                     class_name = ?,
                     day_boarding = ?,
                     admission_fee = ?,
                     uniform_fee = ?,
                     expected_tuition = ?,
                     parent_contact = ?
                 WHERE student_id = ?"
            );
            
            if ($updatePaymentsStmt) {
                $updatePaymentsStmt->bind_param(
                    "ssissdddsi",
                    $first_name,
                    $gender,
                    $class_id,
                    $class_name,
                    $day_boarding,
                    $admission_fee,
                    $uniform_fee,
                    $expected_tuition,
                    $parent_contact,
                    $student_id
                );
                $updatePaymentsStmt->execute();
                $affectedRows = $updatePaymentsStmt->affected_rows; // NEW: Check how many rows were updated
                $updatePaymentsStmt->close();
                
                // NEW: Log if no payment records were updated (for debugging)
                if ($affectedRows === 0) {
                    error_log("Warning: No payment records updated for student_id: $student_id");
                }
            }

            // 4. Also update student_payment_topups table
            $updateTopupsStmt = $mysqli->prepare(
                "UPDATE student_payment_topups 
                 SET full_name = ?
                 WHERE student_id = ?"
            );
            
            if ($updateTopupsStmt) {
                $updateTopupsStmt->bind_param("si", $first_name, $student_id);
                $updateTopupsStmt->execute();
                $updateTopupsStmt->close();
            }

            $mysqli->commit();

            // Re‑read CURRENT admission_no after update for logging
            $currentSn = null;
            $snStmt = $mysqli->prepare("SELECT admission_no FROM admit_students WHERE id = ?");
            if ($snStmt) {
                $snStmt->bind_param("i", $student_id);
                $snStmt->execute();
                $snRes = $snStmt->get_result();
                $snRow = $snRes->fetch_assoc();
                $currentSn = $snRow['admission_no'] ?? null;
                $snStmt->close();
            }

            // Log detailed changes only for principal
            if (isset($_SESSION['role']) && $_SESSION['role'] === 'principal' && $oldData && $currentSn !== null) {
                $changes = [];

                if ($oldData['first_name'] !== $first_name) {
                    $changes[] = "Name: {$oldData['first_name']} → {$first_name}";
                }
                if ($oldData['gender'] !== $gender) {
                    $changes[] = "Gender: {$oldData['gender']} → {$gender}";
                }
                if ((string)$oldData['class_id'] !== (string)$class_id) {
                    $changes[] = "Class ID: {$oldData['class_id']} → {$class_id}";
                }
                if ($oldData['day_boarding'] !== $day_boarding) {
                    $changes[] = "Type (Day/Boarding): {$oldData['day_boarding']} → {$day_boarding}";
                }
                if ((float)$oldData['admission_fee'] != (float)$admission_fee) {
                    $changes[] = "Admission Fee: ".
                        number_format((float)$oldData['admission_fee'], 2).
                        " → ".
                        number_format((float)$admission_fee, 2);
                }
                if ((float)$oldData['uniform_fee'] != (float)$uniform_fee) {
                    $changes[] = "Uniform Fee: ".
                        number_format((float)$oldData['uniform_fee'], 2).
                        " → ".
                        number_format((float)$uniform_fee, 2);
                }
                if ($oldData['parent_contact'] !== $parent_contact) {
                    $changes[] = "Parent Contact: {$oldData['parent_contact']} → {$parent_contact}";
                }

                $snText = $currentSn;
                $changeSummary = empty($changes)
                    ? "No field values actually changed."
                    : implode("; ", $changes);

                $entityName = $first_name;
                $details = "Principal edited admitted student SN {$snText}. Changes: {$changeSummary}. All related payment records updated automatically.";
                $ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

                $logSql = "INSERT INTO activity_logs
                    (user_id, user_name, user_role, action, entity_type, entity_id, entity_name, details, ip_address, is_acknowledged, created_at)
                    VALUES (?, ?, ?, 'edit', 'admit_student', ?, ?, ?, ?, 0, NOW())";
                $logStmt = $mysqli->prepare($logSql);
                if ($logStmt) {
                    $logStmt->bind_param(
                        "ississs",
                        $_SESSION['user_id'],
                        $_SESSION['name'],
                        $_SESSION['role'],
                        $student_id,
                        $entityName,
                        $details,
                        $ipAddress
                    );
                    $logStmt->execute();
                    $logStmt->close();
                }
            }

            header("Location: admitStudents.php?student_updated=1");
            exit();
            
        } catch (Throwable $e) {
            $mysqli->rollback();
            error_log("Error updating student: " . $e->getMessage());
            $error = "Error updating student: " . $e->getMessage();
        }
    }
}

// Check for success message from redirect
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $message = "Student admitted successfully!";
}

// Check for update message
if (isset($_GET['updated']) && $_GET['updated'] == 1) {
    $message = "Student information updated successfully!";
}

// Check for deletion message
if (isset($_GET['deleted']) && $_GET['deleted'] == 1) {
    $message = "Student deleted successfully!";
}

// Check for deletion error
if (isset($_GET['error']) && $_GET['error'] == 1) {
    $error = "Error deleting student. Please try again.";
}

// Include layout AFTER all header operations
require_once __DIR__ . '/../helper/layout.php';

// Build filter query
$filterWhere = "1=1";
$search_filter = $_GET['search'] ?? '';
$class_filter = $_GET['class'] ?? '';
$gender_filter = $_GET['gender'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$day_boarding_filter = $_GET['day_boarding'] ?? ''; // Remove default filter
$sort_order = $_GET['sort'] ?? 'ASC'; // Changed default to ASC (ascending order)

// Toggle sort order
$next_sort_order = ($sort_order === 'ASC') ? 'DESC' : 'ASC';

if ($search_filter) {
    $searchTerm = '%' . $mysqli->real_escape_string($search_filter) . '%';
    $filterWhere .= " AND (admit_students.first_name LIKE '$searchTerm' OR admit_students.admission_no LIKE '$searchTerm')";
}
if ($class_filter) {
    $filterWhere .= " AND admit_students.class_id = " . intval($class_filter);
}
if ($gender_filter) {
    $filterWhere .= " AND admit_students.gender = '" . $mysqli->real_escape_string($gender_filter) . "'";
}
if ($date_from) {
    $filterWhere .= " AND DATE(admit_students.created_at) >= '" . $mysqli->real_escape_string($date_from) . "'";
}
if ($date_to) {
    $filterWhere .= " AND DATE(admit_students.created_at) <= '" . $mysqli->real_escape_string($date_to) . "'";
}
if ($day_boarding_filter) {
    $filterWhere .= " AND admit_students.day_boarding = '" . $mysqli->real_escape_string($day_boarding_filter) . "'";
}

// Pagination setup
$records_per_page = 60;
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($current_page - 1) * $records_per_page;

// Get total count for pagination
$countQuery = "SELECT COUNT(*) as total FROM admit_students 
              LEFT JOIN classes c ON admit_students.class_id = c.id
              WHERE $filterWhere";
$countResult = $mysqli->query($countQuery);
$countRow = $countResult->fetch_assoc();
$total_records = $countRow['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get admitted students - with filters, sorting and pagination
$studentsQuery = "SELECT 
    admit_students.id,
    admission_no,
    first_name,
    gender,
    class_id,
    c.class_name,
    day_boarding,
    admission_fee,
    uniform_fee,
    expected_tuition,
    parent_contact,
    status,
    created_at
FROM admit_students
LEFT JOIN classes c ON admit_students.class_id = c.id
WHERE $filterWhere
ORDER BY CAST(admission_no AS UNSIGNED) $sort_order
LIMIT $offset, $records_per_page";

$studentsResult = $mysqli->query($studentsQuery);
$students = $studentsResult->fetch_all(MYSQLI_ASSOC);

// NEW: Calculate grand totals for ALL records (not just current page)
$totalsQuery = "SELECT 
    SUM(admission_fee) as total_admission,
    SUM(uniform_fee) as total_uniform,
    SUM(expected_tuition) as total_expected
FROM admit_students
LEFT JOIN classes c ON admit_students.class_id = c.id
WHERE $filterWhere";

$totalsResult = $mysqli->query($totalsQuery);
$totals = $totalsResult->fetch_assoc();

// Get current user role
$userRole = $_SESSION['role'] ?? '';
$canAdmitStudent = in_array($userRole, ['admin', 'principal']);
$canEditStudent = in_array($userRole, ['admin', 'principal', 'bursar']); // NEW: Bursar can edit
$canDeleteStudent = ($userRole === 'admin'); // Only admin can delete
?>

<!DOCTYPE html>

<!-- Toggle Button for Admit Student Form -->
<div class="mb-3">
    <?php if ($canAdmitStudent): ?>
        <button type="button" class="btn-toggle-form" onclick="toggleAdmitForm()">
            <i class="bi bi-chevron-right"></i> Admit New Student
        </button>
    <?php else: ?>
        <button type="button" class="btn-toggle-form" data-bs-toggle="modal" data-bs-target="#admitRestrictionModal">
            <i class="bi bi-chevron-right"></i> Admit New Student
        </button>
    <?php endif; ?>
</div>

<!-- Admit Student Form (Collapsible) - Only show if user can admit -->
<?php if ($canAdmitStudent): ?>
    <div class="card shadow-sm border-0 mb-4" id="admitFormCard" style="display: none;">
        <div class="card-header form-header text-white">
            <h5 class="mb-0">Admit New Student</h5>
        </div>
        <div class="card-body">
            <?php if (!empty($message)): ?>
                <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="first_name" class="form-control" placeholder="Student full name" required>
                </div>

                <div class="col-md-4">
                    <label class="form-label">F/M</label>
                    <select name="gender" class="form-control" required>
                        <option value="">Select</option>
                        <option value="Male">M</option>
                        <option value="Female">F</option>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Class</label>
                    <select name="class_id" class="form-control" required>
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option 
                                value="<?= $class['class_id'] ?>"
                                data-expected-tuition="<?= htmlspecialchars($class['expected_tuition'] ?? 0) ?>"
                            >
                                <?= htmlspecialchars($class['class_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Day/Boarding</label>
                    <select name="day_boarding" class="form-control" required>
                        <option value="">Select Option</option>
                        <option value="Day">Day</option>
                        <option value="Boarding">Boarding</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Admission Fee</label>
                    <input type="number" name="admission_fee" class="form-control" step="0.01" min="0" placeholder="0.00">
                </div>

                <div class="col-md-3">
                    <label class="form-label">Uniform Fee</label>
                    <input type="number" name="uniform_fee" class="form-control" step="0.01" min="0" placeholder="0.00">
                </div>

                <div class="col-md-3">
                    <label class="form-label">Expected Tuition</label>
                    <input type="number" name="expected_tuition" id="expectedTuition" class="form-control readonly-field" step="0.01" min="0" readonly>
                    <small class="text-muted">Auto-filled from tuition setup</small>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Parent Contact</label>
                    <input type="text" name="parent_contact" class="form-control" placeholder="e.g., 0774323232" required>
                    <small class="text-muted">Enter phone number with leading zeros</small>
                </div>

                <div class="col-12">
                    <button type="submit" name="admit_student" class="btn btn-form-submit">
                        <i class="bi bi-person-plus"></i> Admit Student
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>

<!-- Filter Section -->
<div class="card filter-card">
    <div class="card-body">
        <form method="GET">
            <div class="filter-row">
                <div class="filter-group">
                    <label>Search Student</label>
                    <input type="text" name="search" class="form-control" placeholder="Name, Admission No" value="<?= htmlspecialchars($search_filter) ?>">
                </div>

                <div class="filter-group">
                    <label>Class</label>
                    <select name="class" class="form-control">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?= $class['class_id'] ?>" <?= $class_filter == $class['class_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($class['class_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="filter-group">
                    <label>Gender</label>
                    <select name="gender" class="form-control">
                        <option value="">All Genders</option>
                        <option value="Male" <?= $gender_filter === 'Male' ? 'selected' : '' ?>>Male</option>
                        <option value="Female" <?= $gender_filter === 'Female' ? 'selected' : '' ?>>Female</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label>Day/Boarding</label>
                    <select name="day_boarding" class="form-control">
                        <option value="">All Students</option>
                        <option value="Day" <?= $day_boarding_filter === 'Day' ? 'selected' : '' ?>>Day</option>
                        <option value="Boarding" <?= $day_boarding_filter === 'Boarding' ? 'selected' : '' ?>>Boarding</option>
                    </select>
                </div>

                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                </div>

                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                </div>

                <div class="filter-group">
                    <div class="filter-buttons">
                        <button type="submit" class="btn-filter">
                            <i class="bi bi-funnel"></i> Filter
                        </button>
                        <a href="admitStudents.php" class="btn-reset">
                            <i class="bi bi-arrow-clockwise"></i>
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Admitted Students Table (All students in one table) -->
<div class="card shadow-sm border-0">
    <div class="card-body">
        <?php if (empty($students)): ?>
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> No students found.
            </div>
        <?php else: ?>
            <div class="table-container">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>
                                <a href="?sort=<?= $next_sort_order ?><?php echo ($search_filter ? '&search=' . urlencode($search_filter) : '') . ($class_filter ? '&class=' . $class_filter : '') . ($gender_filter ? '&gender=' . $gender_filter : '') . ($day_boarding_filter ? '&day_boarding=' . $day_boarding_filter : '') . ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>" style="text-decoration: none; color: white; display: flex; align-items: center; gap: 8px;">
                                    SN
                                    <i class="bi <?= $sort_order === 'ASC' ? 'bi-sort-up' : 'bi-sort-down' ?>"></i>
                                </a>
                            </th>
                            <th>Name</th>
                            <th>F/M</th>
                            <th>Class</th>
                            <th>Day/Boarding</th>
                            <th>Adm Fee</th>
                            <th>U Fee</th>
                            <th>Exp Tuition</th>
                            <th>Parent Contact</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sn = $offset + 1; // continuous SN across pages ?>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?= $sn ?></td>
                                <?php $sn++; ?>
                                <td><?= htmlspecialchars($student['first_name']) ?></td>
                                <td><?= $student['gender'] === 'Male' ? 'M' : 'F' ?></td>
                                <td><?= htmlspecialchars($student['class_name'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($student['day_boarding']) ?></td>
                                <td><?= number_format($student['admission_fee'], 2) ?></td>
                                <td><?= number_format($student['uniform_fee'], 2) ?></td>
                                <td><?= number_format($student['expected_tuition'], 2) ?></td>
                                <td><?= htmlspecialchars($student['parent_contact']) ?></td>
                                <td><?= date('Y-m-d H:i', strtotime($student['created_at'])) ?></td>
                                <td>
                                    <span class="badge <?= $student['status'] === 'approved' ? 'bg-success' : 'bg-danger' ?>">
                                        <?= ucfirst($student['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <?php if ($canEditStudent): ?>
                                            <!-- Edit button - now available for bursar too -->
                                            <button type="button" class="btn-icon-edit" title="Edit" data-bs-toggle="modal" data-bs-target="#editModal" onclick="loadEditForm(<?= $student['id'] ?>, '<?= htmlspecialchars($student['first_name']) ?>', '<?= htmlspecialchars($student['gender']) ?>', <?= $student['admission_fee'] ?>, <?= $student['uniform_fee'] ?>, '<?= htmlspecialchars($student['parent_contact']) ?>', '<?= htmlspecialchars($student['day_boarding']) ?>', <?= $student['class_id'] ?>)">
                                                <i class="bi bi-pencil-square"></i>
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="btn-icon-edit-restricted" title="Edit" data-bs-toggle="modal" data-bs-target="#admitRestrictionModal">
                                                <i class="bi bi-pencil-square"></i>
                                            </button>
                                        <?php endif; ?>

                                        <?php if ($canDeleteStudent): ?>
                                            <!-- Delete button - restricted for bursar -->
                                            <a href="deleteStudent.php?id=<?= $student['id'] ?>" class="btn-icon-delete" title="Delete" onclick="return confirm('Are you sure?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        <?php else: ?>
                                            <button type="button" class="btn-icon-delete-restricted" title="Delete" data-bs-toggle="modal" data-bs-target="#deleteRestrictionModal">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- NEW: Totals Row -->
            <div class="admitted-totals-row">
                <div class="totals-content">
                    <span class="totals-label">TOTALS:</span>
                    <div class="totals-values">
                        <div class="total-item">
                            <span class="total-item-label">Admission Fee:</span>
                            <span class="total-item-value totals-admission-fee"><?= number_format($totals['total_admission'] ?? 0, 2) ?></span>
                        </div>
                        <div class="total-item">
                            <span class="total-item-label">Uniform Fee:</span>
                            <span class="total-item-value totals-uniform-fee"><?= number_format($totals['total_uniform'] ?? 0, 2) ?></span>
                        </div>
                        <div class="total-item">
                            <span class="total-item-label">Expected Tuition:</span>
                            <span class="total-item-value totals-expected-tuition"><?= number_format($totals['total_expected'] ?? 0, 2) ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav aria-label="Page navigation" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= max(1, $current_page - 1) ?>&sort=<?= $sort_order ?><?php echo ($search_filter ? '&search=' . urlencode($search_filter) : '') . ($class_filter ? '&class=' . $class_filter : '') . ($gender_filter ? '&gender=' . $gender_filter : '') . ($day_boarding_filter ? '&day_boarding=' . $day_boarding_filter : '') . ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>

                        <?php
                        $start_page = max(1, $current_page - 2);
                        $end_page = min($total_pages, $current_page + 2);

                        if ($start_page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=1&sort=<?= $sort_order ?><?php echo ($search_filter ? '&search=' . urlencode($search_filter) : '') . ($class_filter ? '&class=' . $class_filter : '') . ($gender_filter ? '&gender=' . $gender_filter : '') . ($day_boarding_filter ? '&day_boarding=' . $day_boarding_filter : '') . ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>">1</a>
                            </li>
                            <?php if ($start_page > 2): ?>
                                <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php for ($page = $start_page; $page <= $end_page; $page++): ?>
                            <li class="page-item <?= $page === $current_page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $page ?>&sort=<?= $sort_order ?><?php echo ($search_filter ? '&search=' . urlencode($search_filter) : '') . ($class_filter ? '&class=' . $class_filter : '') . ($gender_filter ? '&gender=' . $gender_filter : '') . ($day_boarding_filter ? '&day_boarding=' . $day_boarding_filter : '') . ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>">
                                    <?= $page ?>
                                </a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($end_page < $total_pages): ?>
                            <?php if ($end_page < $total_pages - 1): ?>
                                <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $total_pages ?>&sort=<?= $sort_order ?><?php echo ($search_filter ? '&search=' . urlencode($search_filter) : '') . ($class_filter ? '&class=' . $class_filter : '') . ($gender_filter ? '&gender=' . $gender_filter : '') . ($day_boarding_filter ? '&day_boarding=' . $day_boarding_filter : '') . ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>"><?= $total_pages ?></a>
                            </li>
                        <?php endif; ?>

                        <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= min($total_pages, $current_page + 1) ?>&sort=<?= $sort_order ?><?php echo ($search_filter ? '&search=' . urlencode($search_filter) : '') . ($class_filter ? '&class=' . $class_filter : '') . ($gender_filter ? '&gender=' . $gender_filter : '') . ($day_boarding_filter ? '&day_boarding=' . $day_boarding_filter : '') . ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>

                <div class="text-center mt-3">
                    <p class="text-muted" style="font-size: 13px;">
                        Showing <?= ($offset + 1) ?> to <?= min($offset + $records_per_page, $total_records) ?> of <?= $total_records ?> students
                    </p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Edit Student Modal - Now shown for Admin/Principal/Bursar -->
<?php if ($canEditStudent): ?>
    <div class="modal fade" id="editModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header form-header text-white">
                    <h5 class="modal-title">Edit Student Information</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" class="modal-body">
                    <input type="hidden" name="edit_student" value="1">
                    <input type="hidden" name="student_id" id="editStudentId">

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="first_name" id="editFirstName" class="form-control" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">F/M</label>
                            <select name="gender" id="editGender" class="form-control" required>
                                <option value="">Select</option>
                                <option value="Male">M</option>
                                <option value="Female">F</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Class</label>
                            <select name="class_id" id="editClassId" class="form-control" required>
                                <option value="">Select Class</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= $class['class_id'] ?>"><?= htmlspecialchars($class['class_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Day/Boarding</label>
                            <select name="day_boarding" id="editDayBoarding" class="form-control" required>
                                <option value="">Select Option</option>
                                <option value="Day">Day</option>
                                <option value="Boarding">Boarding</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Admission Fee</label>
                            <input type="number" name="admission_fee" id="editAdmissionFee" class="form-control" step="0.01" min="0">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Uniform Fee</label>
                            <input type="number" name="uniform_fee" id="editUniformFee" class="form-control" step="0.01" min="0">
                        </div>

                        <div class="col-md-12">
                            <label class="form-label">Parent Contact</label>
                            <input type="text" name="parent_contact" id="editParentContact" class="form-control" required>
                        </div>
                    </div>

                    <div class="modal-footer mt-4">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-form-submit">
                            <i class="bi bi-check-circle"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Restriction Modal for Admitting Students -->
<div class="modal fade" id="admitRestrictionModal" tabindex="-1" aria-labelledby="admitRestrictionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="admitRestrictionModalLabel">
                    <i class="bi bi-exclamation-triangle-fill"></i> Access Restricted
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <i class="bi bi-shield-lock" style="font-size: 64px; color: #dc3545; margin-bottom: 20px;"></i>
                <h5 class="mb-3">Cannot Admit New Students</h5>
                <p class="text-muted mb-0">
                    Only <strong>Admin</strong> and <strong>Principal</strong> have permission to admit new students.
                </p>
                <p class="text-muted mt-2">
                    As a <strong class="text-primary">Bursar</strong>, you can view and edit student records but cannot admit new students.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle"></i> Close
                </button>
            </div>
        </div>
    </div>
</div>

<!-- NEW: Restriction Modal for Deleting Students -->
<div class="modal fade" id="deleteRestrictionModal" tabindex="-1" aria-labelledby="deleteRestrictionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteRestrictionModalLabel">
                    <i class="bi bi-exclamation-triangle-fill"></i> Access Restricted
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <i class="bi bi-shield-lock" style="font-size: 64px; color: #dc3545; margin-bottom: 20px;"></i>
                <h5 class="mb-3">Cannot Delete Students</h5>
                <p class="text-muted mb-0">
                    Only <strong>Admin</strong> has permission to delete student records.
                </p>
                <p class="text-muted mt-2">
                    As a <strong class="text-primary"><?= htmlspecialchars(ucfirst($userRole)) ?></strong>, you can view and edit student records but cannot delete them.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle"></i> Close
                </button>
            </div>
        </div>
    </div>
</div>

<script src="../../assets/js/admitStudents.js?v=3"></script>

<?php require_once __DIR__ . '/../helper/layout-footer.php'; ?>
