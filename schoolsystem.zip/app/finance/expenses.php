<?php
$title = "Expenses Management";
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../middleware/role.php';

requireRole(['bursar', 'admin', 'principal']);

// ADMIN‑ONLY: delete a single expense row by ID
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['delete_expense'])
    && (isset($_SESSION['role']) && $_SESSION['role'] === 'admin')
) {
    $expenseId = intval($_POST['expense_id'] ?? 0);
    if ($expenseId > 0) {
        // Get expense details BEFORE deletion
        $getExpense = $mysqli->prepare("SELECT category, item, amount, date FROM expenses WHERE id = ?");
        if ($getExpense) {
            $getExpense->bind_param('i', $expenseId);
            $getExpense->execute();
            $expenseData = $getExpense->get_result()->fetch_assoc();
            $getExpense->close();
            
            // If it's a Salaries expense, delete matching payroll record
            if ($expenseData && $expenseData['category'] === 'Salaries') {
                $mysqli->begin_transaction();
                try {
                    // Delete from expenses
                    $delExpense = $mysqli->prepare("DELETE FROM expenses WHERE id = ?");
                    $delExpense->bind_param('i', $expenseId);
                    $delExpense->execute();
                    $delExpense->close();
                    
                    // Delete matching payroll record (same name, date, and salary amount)
                    $delPayroll = $mysqli->prepare("DELETE FROM payroll WHERE name = ? AND date = ? AND salary = ? LIMIT 1");
                    $delPayroll->bind_param('ssd', $expenseData['item'], $expenseData['date'], $expenseData['amount']);
                    $delPayroll->execute();
                    $delPayroll->close();
                    
                    $mysqli->commit();
                } catch (Throwable $e) {
                    $mysqli->rollback();
                    error_log("Error deleting salary expense: " . $e->getMessage());
                }
            } else {
                // Not a salary expense, just delete from expenses
                $stmt = $mysqli->prepare("DELETE FROM expenses WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param('i', $expenseId);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        }
    }
    header("Location: expenses.php?exp_deleted=1");
    exit();
}

// Handle form submission
$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['record_expense'])) {
    $category = trim($_POST['category']);
    $sub_category = trim($_POST['sub_category'] ?? ''); // NEW: sub-category
    $item = trim($_POST['item']);
    $amount = floatval($_POST['amount']);
    $date = trim($_POST['date']);
    
    // Process quantity and unit_price based on sub-category
    $quantity = 0;
    $unit_price = 0;
    $expected = 0;
    
    // For General Expenses, use sub_category to determine fields
    if ($category === 'General Expenses') {
        if ($sub_category === 'Food' || $sub_category === 'Administrative') {
            $quantity = floatval($_POST['quantity'] ?? 0);
            $unit_price = floatval($_POST['unit_price'] ?? 0);
            $expected = $quantity * $unit_price;
        }
        // For Utilities, quantity/unit_price/expected stay 0
    }

    if (!$category || !$item || !$date || !$amount) {
        $error = "Category, Item, Amount, and Date are required";
    } elseif ($category === 'General Expenses' && !$sub_category) {
        $error = "Please select an expense type (Food, Utilities, or Administrative)";
    } elseif ($amount < 0) {
        $error = "Amount cannot be negative";
    } else {
        $user_id = $_SESSION['user_id'];
        
        // Store sub_category in the 'category' field for General Expenses
        $finalCategory = ($category === 'General Expenses') ? $sub_category : $category;
        
        $stmt = $mysqli->prepare("INSERT INTO expenses (category, item, quantity, unit_price, expected, amount, date, recorded_by, created_at, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), 'approved')");
        
        if ($stmt) {
            $stmt->bind_param("ssddddsi", $finalCategory, $item, $quantity, $unit_price, $expected, $amount, $date, $user_id);
            if ($stmt->execute()) {
                header("Location: expenses.php?expense_added=1&tab=" . strtolower($finalCategory));
                exit();
            } else {
                $error = "Error recording expense: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

// ADMIN‑ONLY: bulk delete expenses by category + date range
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['bulk_delete_expenses'])
    && (isset($_SESSION['role']) && $_SESSION['role'] === 'admin')
) {
    $deleteCategory = $_POST['bulk_category'] ?? 'all';
    $deleteFrom     = $_POST['bulk_from'] ?? '';
    $deleteTo       = $_POST['bulk_to']   ?? '';

    if ($deleteFrom && $deleteTo) {
        // Normalize order if user swapped dates
        if ($deleteFrom > $deleteTo) {
            [$deleteFrom, $deleteTo] = [$deleteTo, $deleteFrom];
        }

        $deletedCount = 0;
        $mysqli->begin_transaction();

        try {
            // If deleting Salaries category, also delete matching payroll records
            if ($deleteCategory === 'Salaries' || $deleteCategory === 'all') {
                // Get all salary expenses in date range
                if ($deleteCategory === 'all') {
                    $getSalaries = $mysqli->prepare("SELECT item, date, amount FROM expenses WHERE category = 'Salaries' AND DATE(`date`) BETWEEN ? AND ?");
                } else {
                    $getSalaries = $mysqli->prepare("SELECT item, date, amount FROM expenses WHERE category = 'Salaries' AND DATE(`date`) BETWEEN ? AND ?");
                }
                $getSalaries->bind_param('ss', $deleteFrom, $deleteTo);
                $getSalaries->execute();
                $salariesResult = $getSalaries->get_result();
                $salariesToDelete = $salariesResult->fetch_all(MYSQLI_ASSOC);
                $getSalaries->close();
                
                // Delete matching payroll records
                foreach ($salariesToDelete as $salary) {
                    $delPayroll = $mysqli->prepare("DELETE FROM payroll WHERE name = ? AND date = ? AND salary = ? LIMIT 1");
                    $delPayroll->bind_param('ssd', $salary['item'], $salary['date'], $salary['amount']);
                    $delPayroll->execute();
                    $delPayroll->close();
                }
            }
            
            // Now delete expenses
            if ($deleteCategory === 'all') {
                $sql  = "DELETE FROM expenses WHERE DATE(`date`) BETWEEN ? AND ?";
                $stmt = $mysqli->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param('ss', $deleteFrom, $deleteTo);
                    $stmt->execute();
                    $deletedCount = $stmt->affected_rows;
                    $stmt->close();
                }
            } else {
                $sql  = "DELETE FROM expenses WHERE DATE(`date`) BETWEEN ? AND ? AND category = ?";
                $stmt = $mysqli->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param('sss', $deleteFrom, $deleteTo, $deleteCategory);
                    $stmt->execute();
                    $deletedCount = $stmt->affected_rows;
                    $stmt->close();
                }
            }

            $mysqli->commit();
            header("Location: expenses.php?bulk_deleted=" . (int)$deletedCount);
            exit();
        } catch (Throwable $e) {
            $mysqli->rollback();
            error_log("Error in bulk delete: " . $e->getMessage());
        }
    }
}

// Include layout AFTER header operations
require_once __DIR__ . '/../helper/layout.php';

// Get active tab
$active_tab = $_GET['tab'] ?? 'salaries';

// Build filter query
$filterWhere = "1=1";
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

if ($date_from) {
    $filterWhere .= " AND DATE(expenses.date) >= '" . $mysqli->real_escape_string($date_from) . "'";
}
if ($date_to) {
    $filterWhere .= " AND DATE(expenses.date) <= '" . $mysqli->real_escape_string($date_to) . "'";
}

// Add category filter based on active tab
if ($active_tab === 'salaries') {
    $filterWhere .= " AND expenses.category = 'Salaries'";
} elseif ($active_tab === 'general') {
    $filterWhere .= " AND expenses.category IN ('Food', 'Utilities', 'Administrative')";
}

// Pagination setup
$records_per_page = 50;
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($current_page - 1) * $records_per_page;

// Get total count for pagination
$countQuery = "SELECT COUNT(*) as total FROM expenses WHERE $filterWhere";
$countResult = $mysqli->query($countQuery);
$countRow = $countResult->fetch_assoc();
$total_records = $countRow['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get expenses with user info
$query = "SELECT 
    expenses.id,
    expenses.category,
    expenses.item,
    expenses.quantity,
    expenses.unit_price,
    expenses.expected,
    expenses.amount,
    expenses.date,
    expenses.status,
    users.name as recorded_by,
    expenses.created_at
FROM expenses
LEFT JOIN users ON expenses.recorded_by = users.id
WHERE $filterWhere
ORDER BY expenses.date DESC, expenses.created_at DESC
LIMIT $offset, $records_per_page";

$result = $mysqli->query($query);
$expenses = $result->fetch_all(MYSQLI_ASSOC);

// Calculate totals
$totalsQuery = "SELECT 
    COUNT(*) as total_count,
    SUM(amount) as total_amount,
    SUM(quantity) as total_quantity
FROM expenses
WHERE $filterWhere";

$totalsResult = $mysqli->query($totalsQuery);
$totals = $totalsResult->fetch_assoc();

// Get current user role
$userRole = $_SESSION['role'] ?? '';
$canRecordExpense = in_array($userRole, ['admin', 'bursar']);
?>

<!-- Toggle Button for Expense Form -->
<div class="mb-3">
    <?php if ($canRecordExpense): ?>
        <button type="button" class="btn-toggle-form" onclick="toggleExpenseForm()">
            <i class="bi bi-chevron-down" id="toggleIcon"></i>
            <span id="toggleText">Show Form</span>
        </button>
    <?php else: ?>
        <button type="button" class="btn-toggle-form" data-bs-toggle="modal" data-bs-target="#expenseRestrictionModal">
            <i class="bi bi-chevron-down"></i>
            <span>Show Form</span>
        </button>
    <?php endif; ?>
</div>

<!-- Expense Form (Collapsible) - Only show if user can record -->
<?php if ($canRecordExpense): ?>
    <div class="card shadow-sm border-0 mb-4" id="expenseFormCard" style="display: none;">
        <div class="card-header form-header text-white">
            <h5 class="mb-0">Record Expense</h5>
        </div>
        <div class="card-body">
            <?php if (!empty($message)): ?>
                <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" class="row g-3" id="expenseForm">
                <div class="col-md-4">
                    <label class="form-label">Category</label>
                    <select name="category" id="category" class="form-control" required onchange="handleCategoryChange()">
                        <option value="">Select Category</option>
                        <option value="General Expenses">General Expenses</option>
                    </select>
                </div>

                <!-- NEW: Sub-Category field (only for General Expenses) -->
                <div class="col-md-4" id="subCategoryField" style="display: none;">
                    <label class="form-label">Expense Type</label>
                    <select name="sub_category" id="sub_category" class="form-control" onchange="handleSubCategoryChange()">
                        <option value="">Select Type</option>
                        <option value="Food">Food</option>
                        <option value="Utilities">Utilities</option>
                        <option value="Administrative">Administrative</option>
                    </select>
                </div>

                <div class="col-md-4" id="itemField">
                    <label class="form-label">Item</label>
                    <input type="text" name="item" class="form-control" placeholder="e.g., Rice, Electricity, Office Supplies" required>
                </div>

                <div class="col-md-4" id="quantityField" style="display: none;">
                    <label class="form-label">Quantity</label>
                    <input type="number" name="quantity" id="quantity" class="form-control" step="0.01" min="0" placeholder="0" value="0" oninput="calculateExpected()">
                </div>

                <div class="col-md-4" id="unitPriceField" style="display: none;">
                    <label class="form-label">Unit Price</label>
                    <input type="number" name="unit_price" id="unit_price" class="form-control" step="0.01" min="0" placeholder="0.00" value="0" oninput="calculateExpected()">
                </div>

                <div class="col-md-4" id="expectedField" style="display: none;">
                    <label class="form-label">Expected</label>
                    <input type="number" name="expected" id="expected" class="form-control readonly-field" step="0.01" placeholder="0.00" value="0.00" readonly style="background-color: #e9ecef;">
                </div>

                <div class="col-md-4" id="amountField">
                    <label class="form-label">Amount Paid ($)</label>
                    <input type="number" name="amount" class="form-control" step="0.01" min="0" placeholder="0.00" required>
                </div>

                <div class="col-md-4" id="dateField">
                    <label class="form-label">Date</label>
                    <input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>

                <div class="col-md-4" id="submitField" style="display: flex; align-items: flex-end;">
                    <button type="submit" name="record_expense" class="btn btn-form-submit w-100">
                        <i class="bi bi-plus-circle"></i> Record Expense
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>

<!-- Filter Section -->
<div class="card filter-card">
    <div class="card-body">
        <form method="GET">
            <input type="hidden" name="tab" value="<?= htmlspecialchars($active_tab) ?>">
            <div class="filter-row">
                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                </div>

                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                </div>

                <div class="filter-group">
                    <div class="filter-buttons">
                        <button type="submit" class="btn-filter">
                            <i class="bi bi-funnel"></i> Filter
                        </button>
                        <a href="expenses.php?tab=<?= htmlspecialchars($active_tab) ?>" class="btn-reset">
                            <i class="bi bi-arrow-clockwise"></i>
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Expense Tabs -->
<div class="expense-tabs-container">
    <div class="expense-tabs">
        <a href="?tab=salaries<?= $date_from ? '&date_from=' . $date_from : '' ?><?= $date_to ? '&date_to=' . $date_to : '' ?>" 
           class="expense-tab-btn <?= $active_tab === 'salaries' ? 'active' : '' ?>">
            <i class="bi bi-person-badge"></i> Salaries
        </a>
        <a href="?tab=general<?= $date_from ? '&date_from=' . $date_from : '' ?><?= $date_to ? '&date_to=' . $date_to : '' ?>" 
           class="expense-tab-btn <?= $active_tab === 'general' ? 'active' : '' ?>">
            <i class="bi bi-receipt"></i> General Expenses
        </a>
    </div>
</div>

<!-- Success Message for Deleted Records -->
<?php /* REMOVED - toast will handle this
if (isset($_GET['deleted']) && is_numeric($_GET['deleted'])): ?>
    <div class="alert alert-success alert-sm">
        <i class="bi bi-check-circle"></i>
        <?= (int)$_GET['deleted'] ?> expense record(s) deleted successfully.
    </div>
<?php endif;
*/ ?>

<!-- REMOVED - toast will handle this
<?php if (isset($_GET['exp_deleted']) && $_GET['exp_deleted'] == 1): ?>
    <div class="alert alert-success alert-sm">
        <i class="bi bi-check-circle"></i>
        Expense record deleted successfully.
    </div>
<?php endif; ?>
-->

<!-- Expenses Table -->
<div class="card shadow-sm border-0">
    <div class="card-body">
        <h5 class="mb-3">Expenses Records</h5>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <!-- Admin‑only bulk delete button -->
            <button type="button"
                    class="btn btn-danger mb-3"
                    data-bs-toggle="modal"
                    data-bs-target="#deleteExpensesByFilterModal">
                <i class="bi bi-trash"></i> Delete Expenses
            </button>
        <?php endif; ?>

        <?php if (empty($expenses)): ?>
            <div class="alert alert-info">No expenses found.</div>
        <?php else: ?>
            <div class="table-container">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Category</th>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Expected</th>
                            <th>Amount Paid</th>
                            <?php if ($active_tab === 'salaries'): ?>
                                <th>Balance ($)</th> <!-- KEEP for Salaries -->
                            <?php endif; ?>
                            <th>Recorded By</th>
                            <th>Status</th>
                            <th>Actions</th> <!-- New Actions column -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($expenses as $expense): ?>
                            <tr>
                                <td><?= date('Y-m-d', strtotime($expense['date'])) ?></td>
                                <td><?= htmlspecialchars($expense['category']) ?></td>
                                <td><?= htmlspecialchars($expense['item']) ?></td>
                                <td><?= number_format($expense['quantity'], 2) ?></td>
                                <td><?= number_format($expense['unit_price'], 2) ?></td>
                                <td><?= number_format($expense['expected'], 2) ?></td>
                                <td><?= number_format($expense['amount'], 2) ?></td>
                                <?php if ($active_tab === 'salaries'): ?>
                                    <?php
                                    $expected = (float)($expense['expected'] ?? 0);
                                    $paid     = (float)($expense['amount'] ?? 0);
                                    $balance  = max(0, $expected - $paid);
                                    ?>
                                    <td><?= number_format($balance, 2) ?></td> <!-- KEEP -->
                                <?php endif; ?>
                                <td><?= htmlspecialchars($expense['recorded_by'] ?? 'System') ?></td>
                                <td>
                                    <?php if ($expense['status'] === 'approved'): ?>
                                        <span class="badge bg-success">Approved</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Unapproved</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this expense record?');">
                                            <input type="hidden" name="expense_id" value="<?= (int)$expense['id'] ?>">
                                            <button type="submit" name="delete_expense" class="btn btn-sm btn-danger" title="Delete Expense">
                                                <i class="bi bi-trash"></i> Delete
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <button type="button"
                                                class="btn btn-sm btn-danger"
                                                title="Delete Expense"
                                                data-bs-toggle="modal"
                                                data-bs-target="#expensesRestrictionModal">
                                            <i class="bi bi-trash"></i> Delete
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        
                        <!-- Totals Row -->
                        <tr class="table-totals">
                            <td colspan="6" class="text-end fw-bold">TOTALS:</td>
                            <td><?= number_format($totals['total_amount'] ?? 0, 2) ?></td>
                            <td colspan="2"></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav aria-label="Page navigation" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <!-- Previous Button -->
                        <li class="page-item <?= $current_page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= max(1, $current_page - 1) ?>&tab=<?= urlencode($active_tab) ?><?php echo ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>

                        <!-- Page Numbers -->
                        <?php
                        $start_page = max(1, $current_page - 2);
                        $end_page = min($total_pages, $current_page + 2);

                        if ($start_page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=1&tab=<?= urlencode($active_tab) ?><?php echo ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>">1</a>
                            </li>
                            <?php if ($start_page > 2): ?>
                                <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php for ($page = $start_page; $page <= $end_page; $page++): ?>
                            <li class="page-item <?= $page === $current_page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $page ?>&tab=<?= urlencode($active_tab) ?><?php echo ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>">
                                    <?= $page ?>
                                </a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($end_page < $total_pages): ?>
                            <?php if ($end_page < $total_pages - 1): ?>
                                <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $total_pages ?>&tab=<?= urlencode($active_tab) ?><?php echo ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>"><?= $total_pages ?></a>
                            </li>
                        <?php endif; ?>

                        <!-- Next Button -->
                        <li class="page-item <?= $current_page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= min($total_pages, $current_page + 1) ?>&tab=<?= urlencode($active_tab) ?><?php echo ($date_from ? '&date_from=' . $date_from : '') . ($date_to ? '&date_to=' . $date_to : ''); ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>

                <!-- Pagination Info -->
                <div class="text-center mt-3">
                    <p class="text-muted" style="font-size: 13px;">
                        Showing <?= ($offset + 1) ?> to <?= min($offset + $records_per_page, $total_records) ?> of <?= $total_records ?> expenses
                    </p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
    <!-- Admin‑only modal: delete expenses by category + date range -->
    <div class="modal fade" id="deleteExpensesByFilterModal" tabindex="-1" aria-labelledby="deleteExpensesByFilterLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deleteExpensesByFilterLabel">
                        <i class="bi bi-trash"></i> Delete Expenses
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3">
                        This will permanently delete all expense records that match the selected
                        category and date range.
                    </p>

                    <div class="mb-3">
                        <label for="bulk_category" class="form-label">Category</label>
                        <select class="form-control" id="bulk_category" name="bulk_category" required>
                            <option value="all">All Categories</option>
                            <option value="Salaries">Salaries</option>
                            <option value="Food">Food</option>
                            <option value="Utilities">Utilities</option>
                            <option value="Administrative">Administrative</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="bulk_from" class="form-label">From Date</label>
                        <input type="date" class="form-control" id="bulk_from" name="bulk_from" required>
                    </div>
                    <div class="mb-3">
                        <label for="bulk_to" class="form-label">To Date</label>
                        <input type="date" class="form-control" id="bulk_to" name="bulk_to" required>
                    </div>

                    <div class="alert alert-warning small mb-0">
                        <i class="bi bi-exclamation-triangle"></i>
                        This action cannot be undone. Please make sure the category and dates are correct.
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="bulk_delete_expenses" value="1">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Delete Records
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>

<!-- Restriction Modal for Principal -->
<div class="modal fade" id="expenseRestrictionModal" tabindex="-1" aria-labelledby="expenseRestrictionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="expenseRestrictionModalLabel">
                    <i class="bi bi-exclamation-triangle-fill"></i> Access Restricted
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <i class="bi bi-shield-lock" style="font-size: 64px; color: #dc3545; margin-bottom: 20px;"></i>
                <h5 class="mb-3">Cannot Record Expense</h5>
                <p class="text-muted mb-0">
                    Only <strong>Admin</strong> and <strong>Bursar</strong> roles have permission to record expenses.
                </p>
                <p class="text-muted mt-2">
                    As a <strong class="text-primary">Principal</strong>, you can view expense records but cannot create new ones.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle"></i> Close
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Restriction Modal for non‑admin delete attempts -->
<?php if (!$isAdmin): ?>
    <div class="modal fade" id="expensesRestrictionModal" tabindex="-1" aria-labelledby="expensesRestrictionModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="expensesRestrictionModalLabel">
                        <i class="bi bi-exclamation-triangle-fill"></i> Access Restricted
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center py-4">
                    <i class="bi bi-shield-lock" style="font-size: 64px; color: #dc3545; margin-bottom: 20px;"></i>
                    <h5 class="mb-3">Cannot Delete Expenses</h5>
                    <p class="text-muted mb-0">
                        Only <strong>Admin</strong> has permission to delete expense records.
                    </p>
                    <p class="text-muted mt-2">
                        As a <strong class="text-primary"><?= htmlspecialchars(ucfirst($userRole)) ?></strong>, you can view expenses but cannot delete them.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle"></i> Close
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<link rel="stylesheet" href="../../assets/css/expenses.css">
<script src="../../assets/js/expenses.js"></script>

<?php require_once __DIR__ . '/../helper/layout-footer.php'; ?>
